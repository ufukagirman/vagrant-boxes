shared_context :some_context do
  # example only,
  let(:hiera_data) do
    {}
  end
end
